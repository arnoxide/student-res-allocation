<?php

$host = 'localhost:3306';
$user = 'theboxla_new_thebox';
$pass = 'theBox@2021';
$db_name = 'theboxla_new_thebox';

$conn = new MySQLI($host, $user, $pass, $db_name);
date_default_timezone_set('Africa/johannesburg');

?>
 