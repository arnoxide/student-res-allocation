<!--
Author: W3layouts
Author URL: http://w3layouts.com
-->
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <title>Student Allocation | (Res Name)</title>
    <!-- web fonts -->
    <link href="//fonts.googleapis.com/css?family=Poppins:300,400,500,600,700,800,900&display=swap" rel="stylesheet">
    <link href="//fonts.googleapis.com/css?family=Hind&display=swap" rel="stylesheet">
    <!-- //web fonts -->
    <!-- Template CSS -->
    <link rel="stylesheet" href="../assets/css/style-starter.css">
  </head>
  <body>


<!-- Top Menu 1 -->
<section class="w3l-top-menu-1">
	<div class="top-hd">
		<div class="container">
	<header class="row">
		<div class="social-top col-lg-3 col-6">
			<li>Follow Us</li>
			<li><a href="#"><span class="fa fa-facebook"></span></a></li>
			<li><a href="#"><span class="fa fa-instagram"></span></a> </li>
				<li><a href="#"><span class="fa fa-twitter"></span></a></li>
				<li><a href="#"><span class="fa fa-vimeo"></span></a> </li>
		</div>
		<div class="accounts col-lg-9 col-6">
				<li class="top_li"><span class="fa fa-mobile"></span><a href="tel:+142 5897555">+142 5897555</a> </li>
				<li class="top_li1"><a href="#">Login</a></li>
				<li class="top_li2"><a href="#">Register</a></li>
		</div>
		
	</header>
</div>
</div>
</section>
<!-- //Top Menu 1 -->
<section class="w3l-bootstrap-header">
  <nav class="navbar navbar-expand-lg navbar-light py-lg-2 py-2">
    <div class="container">
      <a class="navbar-brand" href="index.html"><span class="fa fa-home"></span> Univen Res Allocation</a>
      <!-- if logo is image enable this   
    <a class="navbar-brand" href="#index.html">
        <img src="image-path" alt="Your logo" title="Your logo" style="height:35px;" />
    </a> -->
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
        aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon fa fa-bars"></span>
      </button>

      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav ml-auto">
          <li class="nav-item">
            <a class="nav-link" href="index.html">Home</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="about.html">My status</a>
        </li>
        </ul>
       
      </div>
    </div>
  </nav>
</section>



<section class="grids-4" id="properties">
    <div id="grids4-block" class="py-5">
       <div class="container py-md-3">
			<div class="heading text-center mx-auto">
      <h3 class="head">Other Res</h3>
      <p class="my-3 head"> Explore Othe Reses closes to (Res Name).</p>
    </div>
            <div class="row mt-5 pt-3">
                <div class="grids4-info  col-lg-4 col-md-6">
                        <a href="#"><img src="assets/images/g7.jpg" class="img-fluid" alt=""></a>
                        <ul class="location-top">
                            <li class="rent">For Rent</li>
                            <li class="open-1">Open House</li>
                        </ul>
                        <div class="info-bg">
                            <h5><a href="#">Luxury Apartment In chelsea</a></h5>
                            <p>$ 450,000 $777 / sqft</p>
                            <ul>
                                <li><span class="fa fa-bed"></span> 4 Beds</li>
                                <li><span class="fa fa-bath"></span> 3 Baths</li>
                                <li><span class="fa fa-share-square-o"></span> 1200 sq ft</li>
                            </ul>
                        </div>
                    </div>
                <div class="grids4-info col-lg-4 col-md-6 mt-md-0 mt-5">
                        <a href="#"><img src="assets/images/g8.jpg" class="img-fluid" alt=""></a>
                        <ul class="location-top">
                            <li class="sale">For Sale</li>
                            <li class="open-1">Open House</li>
                        </ul>
                        <div class="info-bg">
                            <h5><a href="#">Nature-Friendly Family Houses</a></h5>
                            <p>$ 1,350 / per month</p>
                            <ul>
                                <li><span class="fa fa-bed"></span> 3 Beds</li>
                                <li><span class="fa fa-bath"></span> 2 Baths</li>
                                <li><span class="fa fa-share-square-o"></span> 1200 sq ft</li>
                            </ul>
                        </div>
                    </div>
                 <div class="grids4-info col-lg-4 col-md-6 mt-lg-0 mt-5">
                        <a href="#"><img src="assets/images/g7.jpg" class="img-fluid" alt=""></a>
                        <ul class="location-top">
                            <li class="rent">For Rent</li>
                            <li class="open-1">Open House</li>
                        </ul>
                        <div class="info-bg">
                            <h5><a href="#">House Rent in Hydepark</a></h5>
                            <p>$ 2,500 /per month</p>
                           <ul>
                                <li><span class="fa fa-bed"></span> 4 Beds</li>
                                <li><span class="fa fa-bath"></span> 3 Baths</li>
                                <li><span class="fa fa-share-square-o"></span> 1200 sq ft</li>
                            </ul>
                        </div>
                    </div>
					 <div class="grids4-info  col-lg-4 col-md-6 mt-5">
                        <a href="#"><img src="assets/images/g8.jpg" class="img-fluid" alt=""></a>
                        <ul class="location-top">
                            <li class="sale">For Sale</li>
                            <li class="open-1">Open House</li>
                        </ul>
                        <div class="info-bg">
                            <h5><a href="#">Apartment in Memorial Texas</a></h5>
                            <p>$ 220,000 550 / Sqft</p>
                            <ul>
                                <li><span class="fa fa-bed"></span> 5 Beds</li>
                                <li><span class="fa fa-bath"></span> 3 Baths</li>
                                <li><span class="fa fa-share-square-o"></span> 1200 sq ft</li>
                            </ul>
                        </div>
                    </div>
					 <div class="grids4-info  col-lg-4 col-md-6 mt-5">
                        <a href="#"><img src="assets/images/g9.jpg" class="img-fluid" alt=""></a>
                        <ul class="location-top">
                            <li class="rent">For Rent</li>
                            <li class="open-1">Open House</li>
                        </ul>
                        <div class="info-bg">
                            <h5><a href="#">Villa in Miami beach Florida</a></h5>
                            <p>$ 150,000 500 / Per Sqft</p>
                            <ul>
                                <li><span class="fa fa-bed"></span> 2 Beds</li>
                                <li><span class="fa fa-bath"></span> 1 Baths</li>
                                <li><span class="fa fa-share-square-o"></span> 1200 sq ft</li>
                            </ul>
                        </div>
                    </div>
					 <div class="grids4-info  col-lg-4 col-md-6 mt-5">
                        <a href="#"><img src="assets/images/g10.jpg" class="img-fluid" alt=""></a>
                        <ul class="location-top">
                            <li class="sale">For Sale</li>
                            <li class="open-1">Open House</li>
                        </ul>
                        <div class="info-bg">
                            <h5><a href="#">Apartment Jacksonville</a></h5>
                            <p>$ 750 /per month</p>
                            <ul>
                                <li><span class="fa fa-bed"></span> 4 Beds</li>
                                <li><span class="fa fa-bath"></span> 3 Baths</li>
                                <li><span class="fa fa-share-square-o"></span> 1200 sq ft</li>
                            </ul>
                        </div>
                    </div>
                </div>
           </div>
    </div>
</section>

<!-- // grids block 5 -->
<script src="../assets/js/jquery-3.3.1.min.js"></script>
<!-- //footer-28 block -->
</section>

<script>
    $(function () {
      $('.navbar-toggler').click(function () {
        $('body').toggleClass('noscroll');
      })
    });
  </script>
  <!-- jQuery first, then Popper.js, then Bootstrap JS -->
  <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js"
    integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous">
  </script>
  
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"
    integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous">
  </script>

<!-- Smooth scrolling -->


</body>

</html>
<!-- // grids block 5 -->
